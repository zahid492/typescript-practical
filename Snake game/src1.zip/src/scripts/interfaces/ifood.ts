import {IPosition} from './iposition';

export interface IFood{
    position: IPosition,
    createFood():void
}

